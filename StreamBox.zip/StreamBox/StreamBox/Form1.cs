﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StreamBox
{
    public partial class frmMovieBox : Form
    {
        public frmMovieBox()
        {
            InitializeComponent();
        }

        private void btnYoutube_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.youtube.com");
        }

        private void btn123M_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www2.123movieshub.sc/123movies-fun/");
        }

        private void btnTwitch_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.twitch.tv");
        }

        private void btnUSB_Click(object sender, EventArgs e)
        {
            OpenFolder("C:\\Users\\Timo\\Documents");
        }

        private void OpenFolder(string folderPath)
        {
            if(System.IO.Directory.Exists(folderPath))
            {
                System.Diagnostics.Process.Start("explorer.exe", folderPath);

            }
            else
            {
                MessageBox.Show("File path does not exist");
            }
        }

        private void btnBrowser_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.google.com");
        }
    }
}
