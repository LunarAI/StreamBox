﻿namespace StreamBox
{
    partial class frmMovieBox
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBrowser = new System.Windows.Forms.Button();
            this.btnUSB = new System.Windows.Forms.Button();
            this.btnTwitch = new System.Windows.Forms.Button();
            this.btn123M = new System.Windows.Forms.Button();
            this.btnYoutube = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnBrowser
            // 
            this.btnBrowser.BackgroundImage = global::StreamBox.Properties.Resources.chromium_logo_100751561_large;
            this.btnBrowser.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBrowser.Location = new System.Drawing.Point(1219, 309);
            this.btnBrowser.Name = "btnBrowser";
            this.btnBrowser.Size = new System.Drawing.Size(165, 140);
            this.btnBrowser.TabIndex = 4;
            this.btnBrowser.UseVisualStyleBackColor = true;
            this.btnBrowser.Click += new System.EventHandler(this.btnBrowser_Click);
            // 
            // btnUSB
            // 
            this.btnUSB.BackColor = System.Drawing.SystemColors.Window;
            this.btnUSB.BackgroundImage = global::StreamBox.Properties.Resources.usb_logo_png_transparent;
            this.btnUSB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnUSB.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnUSB.Location = new System.Drawing.Point(978, 309);
            this.btnUSB.Name = "btnUSB";
            this.btnUSB.Size = new System.Drawing.Size(165, 140);
            this.btnUSB.TabIndex = 3;
            this.btnUSB.UseVisualStyleBackColor = false;
            this.btnUSB.Click += new System.EventHandler(this.btnUSB_Click);
            // 
            // btnTwitch
            // 
            this.btnTwitch.BackgroundImage = global::StreamBox.Properties.Resources.combologo_474x356;
            this.btnTwitch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTwitch.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTwitch.Location = new System.Drawing.Point(746, 309);
            this.btnTwitch.Name = "btnTwitch";
            this.btnTwitch.Size = new System.Drawing.Size(165, 140);
            this.btnTwitch.TabIndex = 2;
            this.btnTwitch.UseVisualStyleBackColor = true;
            this.btnTwitch.Click += new System.EventHandler(this.btnTwitch_Click);
            // 
            // btn123M
            // 
            this.btn123M.BackgroundImage = global::StreamBox.Properties.Resources.download;
            this.btn123M.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn123M.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn123M.Location = new System.Drawing.Point(524, 309);
            this.btn123M.Name = "btn123M";
            this.btn123M.Size = new System.Drawing.Size(165, 140);
            this.btn123M.TabIndex = 1;
            this.btn123M.UseVisualStyleBackColor = true;
            this.btn123M.Click += new System.EventHandler(this.btn123M_Click);
            // 
            // btnYoutube
            // 
            this.btnYoutube.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnYoutube.BackgroundImage = global::StreamBox.Properties.Resources.Old_YouTube_logo;
            this.btnYoutube.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnYoutube.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnYoutube.Location = new System.Drawing.Point(292, 309);
            this.btnYoutube.Name = "btnYoutube";
            this.btnYoutube.Size = new System.Drawing.Size(165, 140);
            this.btnYoutube.TabIndex = 0;
            this.btnYoutube.UseVisualStyleBackColor = false;
            this.btnYoutube.Click += new System.EventHandler(this.btnYoutube_Click);
            // 
            // frmMovieBox
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::StreamBox.Properties.Resources.abstract_bokeh_dark_3616;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1626, 828);
            this.Controls.Add(this.btnBrowser);
            this.Controls.Add(this.btnUSB);
            this.Controls.Add(this.btnTwitch);
            this.Controls.Add(this.btn123M);
            this.Controls.Add(this.btnYoutube);
            this.Name = "frmMovieBox";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnYoutube;
        private System.Windows.Forms.Button btn123M;
        private System.Windows.Forms.Button btnTwitch;
        private System.Windows.Forms.Button btnUSB;
        private System.Windows.Forms.Button btnBrowser;
    }
}

